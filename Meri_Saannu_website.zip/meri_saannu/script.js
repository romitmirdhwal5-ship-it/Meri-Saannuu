const tracks=[
 {title:"Meri Saannu — Demo",artist:"Meri Saannu",src:"music/song-01.mp3"},
 {title:"Your First Song",artist:"Your Artist",src:"music/song-02.mp3"},
 {title:"Dil Ki Baat",artist:"Your Artist",src:"music/song-03.mp3"},
 {title:"Raaton Ka Safar",artist:"Your Artist",src:"music/song-04.mp3"},
 {title:"Yaadon Mein",artist:"Your Artist",src:"music/song-05.mp3"}
];

const audio=document.getElementById("audio"), play=document.getElementById("play"), progress=document.getElementById("progress");
const title=document.getElementById("title"), artist=document.getElementById("artist"), current=document.getElementById("current"), duration=document.getElementById("duration");
const songs=document.getElementById("songs"), volume=document.getElementById("volume"), volumePct=document.getElementById("volumePct");
let index=0, looping=false, plays=Number(localStorage.getItem("meriPlays")||0);

function fmt(s){if(!Number.isFinite(s))return"00:00";return String(Math.floor(s/60)).padStart(2,"0")+":"+String(Math.floor(s%60)).padStart(2,"0")}
function load(i,autoplay=false){index=(i+tracks.length)%tracks.length;const t=tracks[index];title.textContent=t.title;artist.textContent=t.artist;audio.src=t.src;render();if(autoplay)audio.play().catch(()=>{});}
function render(){songs.innerHTML=tracks.map((t,i)=>`<div class="song ${i===index?"active":""}"><span>${i===index?"▶":String(i+1).padStart(2,"0")}</span><button onclick="load(${i},true)">${t.title}</button><span class="artistCol">${t.artist}</span><span>--:--</span></div>`).join("");document.getElementById("songCount").textContent=tracks.length}
play.onclick=()=>{if(audio.paused){audio.play().catch(()=>alert("Add your MP3 files inside the music folder first."))}else audio.pause()};
audio.onplay=()=>{play.textContent="Ⅱ";plays++;localStorage.setItem("meriPlays",plays);document.getElementById("plays").textContent=plays};
audio.onpause=()=>play.textContent="▶";
audio.ontimeupdate=()=>{current.textContent=fmt(audio.currentTime);progress.value=audio.duration?(audio.currentTime/audio.duration*100):0};
audio.onloadedmetadata=()=>duration.textContent=fmt(audio.duration);
progress.oninput=()=>{if(audio.duration)audio.currentTime=progress.value/100*audio.duration};
volume.oninput=()=>{audio.volume=volume.value;volumePct.textContent=Math.round(volume.value*100)+"%"};
document.getElementById("prev").onclick=()=>load(index-1,true);
document.getElementById("next").onclick=()=>load(index+1,true);
document.getElementById("loop").onclick=()=>{looping=!looping;audio.loop=looping;document.getElementById("loop").style.color=looping?"#ff557f":""};
document.getElementById("shuffle").onclick=()=>load(Math.floor(Math.random()*tracks.length),true);
document.getElementById("shuffleAll").onclick=()=>load(Math.floor(Math.random()*tracks.length),true);
document.getElementById("favBtn").onclick=()=>{document.getElementById("favBtn").textContent="♥ Added to Favorites";localStorage.setItem("meriFav","1")};
audio.onended=()=>{if(!looping)load(index+1,true)};
load(0);audio.volume=.8;document.getElementById("plays").textContent=plays;
document.getElementById("onlineCount").textContent=Math.floor(28+Math.random()*12);
document.getElementById("downloadInfo").onclick=()=>alert("Put your legally owned/licensed MP3 files in the music folder and rename them song-01.mp3, song-02.mp3, etc.");
