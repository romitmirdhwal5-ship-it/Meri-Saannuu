# Meri Saannu

A nostalgic old-web music player website.

## Run
Open `index.html` in a browser.

## Add your music
1. Put your own or properly licensed MP3 files inside `music/`.
2. Use the filenames in `script.js`, or edit the `tracks` array there.
3. Upload the whole folder to your hosting provider.

The included tracks are placeholders; no copyrighted music is included.
